import type { ReactNode } from 'react';

interface BrushButtonProps {
  href: string;
  children: ReactNode;
  className?: string;
  external?: boolean;
}

/**
 * A link whose underline is a brushstroke that draws itself on
 * hover and keyboard focus. Pure CSS via the pathLength trick —
 * zero JS, works before hydration.
 */
export default function BrushButton({
  href,
  children,
  className = '',
  external = false,
}: BrushButtonProps) {
  return (
    <a
      href={href}
      {...(external ? { target: '_blank', rel: 'noreferrer noopener' } : {})}
      className={`group inline-flex flex-col gap-1 font-body text-sm uppercase tracking-wide2 text-washi ${className}`}
    >
      <span>{children}</span>
      <svg viewBox="0 0 120 8" aria-hidden="true" focusable="false" className="h-[7px] w-full overflow-visible">
        <path
          d="M2 5 C 32 2, 72 8, 118 4"
          pathLength={1}
          className="fill-none stroke-current stroke-[2.5] [stroke-linecap:round] [stroke-dasharray:1] [stroke-dashoffset:1] transition-[stroke-dashoffset] duration-700 ease-ink group-hover:[stroke-dashoffset:0] group-focus-visible:[stroke-dashoffset:0]"
        />
      </svg>
    </a>
  );
}
