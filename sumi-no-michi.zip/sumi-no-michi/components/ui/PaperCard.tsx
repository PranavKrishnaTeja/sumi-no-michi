'use client';

import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import SealStamp from '@/components/ui/SealStamp';
import BrushButton from '@/components/ui/BrushButton';
import { MQ, prefersReducedMotion } from '@/lib/motion';

interface PaperCardProps {
  title: string;
  seal: string;
  story: string;
  stack: string;
  href: string;
}

/**
 * One work, hung like a scroll in a night exhibition. A hairline
 * of diluted ink frames it; the hanko authenticates it — and the
 * card lives in 3D: it tilts a few degrees toward the pointer,
 * a scroll panel catching the light. Fine pointers only, ±5°,
 * no bounce.
 */
export default function PaperCard({ title, seal, story, stack, href }: PaperCardProps) {
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReducedMotion()) return;
    if (!window.matchMedia('(pointer: fine)').matches) return;
    if (!window.matchMedia(MQ.desktop).matches) return;

    gsap.set(el, { transformPerspective: 900 });
    const rx = gsap.quickTo(el, 'rotationX', { duration: 0.7, ease: 'power3.out' });
    const ry = gsap.quickTo(el, 'rotationY', { duration: 0.7, ease: 'power3.out' });

    const onMove = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      ry(px * 7);
      rx(-py * 5);
    };
    const onLeave = () => {
      rx(0);
      ry(0);
    };

    el.addEventListener('pointermove', onMove, { passive: true });
    el.addEventListener('pointerleave', onLeave);
    return () => {
      el.removeEventListener('pointermove', onMove);
      el.removeEventListener('pointerleave', onLeave);
      gsap.killTweensOf(el);
    };
  }, []);

  return (
    <article
      ref={ref}
      data-panel
      className="relative w-full shrink-0 snap-center border border-washi/20 bg-washi/[0.03] p-8 will-change-transform md:w-[46vw] md:p-12 lg:w-[38vw]"
    >
      <SealStamp char={seal} label={`Seal of ${title}`} className="absolute right-6 top-6" />

      <h3 className="font-display text-4xl text-washi md:text-5xl">{title}</h3>

      <p className="mt-6 max-w-sm font-body text-base leading-relaxed text-washi/75">{story}</p>

      <p className="mt-8 font-body text-[11px] uppercase tracking-wide2 text-washi/55">{stack}</p>

      <div className="mt-10">
        <BrushButton href={href}>View the work</BrushButton>
      </div>
    </article>
  );
}
