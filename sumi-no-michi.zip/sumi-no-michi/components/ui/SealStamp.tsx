'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { MQ } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger, useGSAP);

interface SealStampProps {
  char: string;
  label: string;
  className?: string;
}

/**
 * The hanko. The single place vermilion is permitted, which is
 * exactly what makes it land. Pressed on, not faded in: scale
 * 1.5 → 1 with a hard-out ease and a two-degree settle, like a
 * stamp meeting paper. No bounce.
 */
export default function SealStamp({ char, label, className = '' }: SealStampProps) {
  const ref = useRef<HTMLSpanElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();
      mm.add(MQ.motionOK, () => {
        gsap.fromTo(
          ref.current,
          { scale: 1.5, opacity: 0, rotate: -7 },
          {
            scale: 1,
            opacity: 1,
            rotate: -3,
            duration: 0.55,
            ease: 'power4.out',
            scrollTrigger: { trigger: ref.current, start: 'top 88%', once: true },
          }
        );
      });
    },
    { scope: ref }
  );

  return (
    <span
      ref={ref}
      role="img"
      aria-label={label}
      className={`relative inline-flex h-12 w-12 -rotate-3 items-center justify-center bg-shu font-display text-2xl leading-none text-washi shadow-[inset_0_0_10px_rgba(22,19,14,0.28)] ${className}`}
    >
      {char}
      {/* stamped-ink unevenness */}
      <span
        aria-hidden="true"
        className="absolute inset-0 opacity-25 mix-blend-multiply"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='48' height='48'%3E%3Cfilter id='s'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23s)'/%3E%3C/svg%3E\")",
        }}
      />
    </span>
  );
}
