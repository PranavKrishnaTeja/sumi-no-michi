'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import PaperSection from '@/components/ink/PaperSection';
import CalligraphyTitle from '@/components/ink/CalligraphyTitle';
import Enso from '@/components/ink/Enso';
import BrushButton from '@/components/ui/BrushButton';
import { contact, identity } from '@/lib/content';
import { EASE, MQ } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger, useGSAP);

/**
 * ACT VI — LEGACY
 *
 * The experience opened with an ensō; it closes with one — drawn
 * larger, slower, and stopped at the same 7% gap. The gap is the
 * thesis: the circle stays open, and the visitor is what enters
 * through it. Then, simply: three ways to reach out.
 */
export default function ActLegacy() {
  const ref = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const path = ref.current?.querySelector<SVGPathElement>('.enso-path');
      if (!path) return;

      const mm = gsap.matchMedia();

      mm.add(MQ.motionOK, () => {
        const len = path.getTotalLength();
        gsap.set(path, { strokeDasharray: len, strokeDashoffset: len });
        gsap.to(path, {
          strokeDashoffset: len * 0.07,
          duration: 2.4,
          ease: EASE.draw,
          scrollTrigger: { trigger: ref.current, start: 'top 62%', once: true },
        });
      });
    },
    { scope: ref }
  );

  return (
    <PaperSection
      id="legacy"
      label="Act VI — Legacy"
      className="flex min-h-screen flex-col justify-center py-32"
    >
      <div ref={ref} className="relative mx-auto flex w-full max-w-4xl flex-col items-center text-center">
        <span
          aria-hidden="true"
          className="tategaki absolute -left-2 top-0 hidden font-display text-sm tracking-[0.5em] text-washi/35 lg:block"
        >
          墨の道
        </span>

        <Enso size={240} strokeWidth={9} className="text-washi" />

        <CalligraphyTitle
          text={contact.invite}
          className="mt-12 font-display text-4xl text-washi md:text-5xl"
        />

        <p className="mt-6 max-w-md font-body text-base leading-relaxed text-washi/75">
          {contact.sub}
        </p>

        <div className="mt-14 flex flex-wrap items-center justify-center gap-x-12 gap-y-6">
          {contact.links.map((l) => (
            <BrushButton key={l.label} href={l.href} external={!l.href.startsWith('mailto:')}>
              {l.label}
            </BrushButton>
          ))}
        </div>
      </div>

      <footer className="mx-auto mt-32 flex w-full max-w-5xl flex-col items-center justify-between gap-3 border-t border-washi/12 pt-8 font-body text-[10px] uppercase tracking-wide2 text-washi/55 md:flex-row">
        <span>
          © {identity.year} {identity.name}
        </span>
        <span>{identity.location}</span>
        <span>set in shippori mincho &amp; inter</span>
      </footer>
    </PaperSection>
  );
}
