'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import PaperSection from '@/components/ink/PaperSection';
import CalligraphyTitle from '@/components/ink/CalligraphyTitle';
import BrushDivider from '@/components/ink/BrushDivider';
import { art } from '@/lib/assets';
import { craft, philosophy } from '@/lib/content';
import { EASE, MQ } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger, useGSAP);

/** Organic vertical scatter for the craft garden — asymmetry by design. */
const SCATTER = [0, 14, -8, 22, 4, -14, 10, -4, 18, -10, 6, 12];

/**
 * ACT III — DISCOVERY
 *
 * Philosophy before skills — the why before the what. Three ideas
 * hang in asymmetric balance like inscriptions on a scroll, while
 * the ink-bloom photograph breathes behind them at 14% opacity.
 * Craft is planted as a garden, not listed as a table.
 */
export default function ActDiscovery() {
  const ref = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();

      mm.add(MQ.motionOK, () => {
        // Bloom drifts against the camera.
        gsap.fromTo(
          '[data-bloom]',
          { yPercent: 12 },
          {
            yPercent: -12,
            ease: 'none',
            scrollTrigger: {
              trigger: ref.current,
              start: 'top bottom',
              end: 'bottom top',
              scrub: true,
            },
          }
        );

        // Philosophy blocks soak in one at a time.
        gsap.utils.toArray<HTMLElement>('[data-idea]').forEach((el) => {
          gsap.fromTo(
            el,
            { opacity: 0, y: 26, filter: 'blur(5px)' },
            {
              opacity: 1,
              y: 0,
              filter: 'blur(0px)',
              duration: 1.2,
              ease: EASE.soak,
              scrollTrigger: { trigger: el, start: 'top 80%', once: true },
            }
          );
        });

        // The garden grows in.
        gsap.fromTo(
          '[data-seedling]',
          { opacity: 0, y: 12 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: EASE.soak,
            stagger: { each: 0.05, from: 'random' },
            scrollTrigger: { trigger: '[data-garden]', start: 'top 82%', once: true },
          }
        );
      });
    },
    { scope: ref }
  );

  return (
    <PaperSection id="discovery" label="Act III — Discovery" className="overflow-hidden py-40">
      <div ref={ref} className="relative mx-auto max-w-6xl">
        {/* atmospheric bloom */}
        <div
          data-bloom
          aria-hidden="true"
          className="pointer-events-none absolute -right-[18%] -top-24 w-[62%] opacity-[0.3]"
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={art.bloom.src}
            alt=""
            width={art.bloom.width}
            height={art.bloom.height}
            loading="lazy"
            decoding="async"
            className="h-auto w-full plate"
          />
        </div>

        <p className="font-body text-[11px] uppercase tracking-calligraphy text-washi/55">
          道 · the way
        </p>
        <CalligraphyTitle
          text="Philosophy"
          className="mt-4 font-display text-5xl text-washi md:text-6xl"
        />

        <div className="relative mt-24 grid gap-24 md:grid-cols-12 md:gap-y-32">
          {philosophy.map((p, i) => (
            <div
              key={p.romaji}
              data-idea
              className={`md:col-span-5 ${
                i % 2 === 0 ? 'md:col-start-1' : 'md:col-start-7 md:translate-y-16'
              }`}
            >
              <div className="flex items-baseline gap-5">
                <span aria-hidden="true" className="font-display text-7xl leading-none text-washi">
                  {p.kanji}
                </span>
                <span className="font-body text-[11px] uppercase tracking-wide2 text-washi/55">
                  {p.romaji}
                </span>
              </div>
              <h3 className="mt-6 font-display text-2xl text-washi">{p.title}</h3>
              <p className="mt-4 max-w-sm font-body text-base leading-relaxed text-washi/75">
                {p.body}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-32">
          <BrushDivider />
        </div>

        {/* craft garden */}
        <div data-garden className="mt-20">
          <h3 className="font-body text-[11px] uppercase tracking-calligraphy text-washi/55">
            the tools, planted
          </h3>
          <ul className="mt-12 flex max-w-3xl flex-wrap gap-x-10 gap-y-8">
            {craft.map((c, i) => (
              <li
                key={c}
                data-seedling
                className="group flex items-center gap-3"
                style={{ transform: `translateY(${SCATTER[i % SCATTER.length]}px)` }}
              >
                <span
                  aria-hidden="true"
                  className="h-1.5 w-1.5 rounded-full bg-washi transition-transform duration-500 ease-ink group-hover:scale-[1.8]"
                />
                <span className="font-body text-sm text-washi/75 transition-colors duration-500 group-hover:text-washi">
                  {c}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </PaperSection>
  );
}
