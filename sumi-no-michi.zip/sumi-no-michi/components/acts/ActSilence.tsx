'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import PaperSection from '@/components/ink/PaperSection';
import { MQ, prefersReducedMotion } from '@/lib/motion';

gsap.registerPlugin(useGSAP);

/**
 * ACT I — SILENCE
 *
 * Almost nothing, on purpose. A single character — 間, "the space
 * between" — breathing at 6% ink. A thin line drips downward as
 * the only hint that the painting continues below the frame.
 *
 * The act begins only after the loader dispatches `ink:ready`
 * (with a timeout fallback so nothing can strand the visitor).
 */
export default function ActSilence() {
  const ref = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const kanji = ref.current?.querySelector('[data-kanji]');
      const hint = ref.current?.querySelector('[data-hint]');
      if (!kanji || !hint) return;

      if (prefersReducedMotion()) {
        gsap.set([kanji, hint], { opacity: 1 });
        return;
      }

      let played = false;
      const play = () => {
        if (played) return;
        played = true;
        const mm = gsap.matchMedia();
        mm.add(MQ.motionOK, () => {
          gsap.to(kanji, { opacity: 1, duration: 2.4, ease: 'power2.out' });
          gsap.to(kanji, {
            scale: 1.03,
            duration: 7,
            ease: 'sine.inOut',
            yoyo: true,
            repeat: -1,
          });
          gsap.to(hint, { opacity: 1, duration: 1.2, delay: 1.2, ease: 'power2.out' });
          gsap.fromTo(
            '[data-hint-line]',
            { scaleY: 0, transformOrigin: 'top' },
            { scaleY: 1, duration: 1.6, ease: 'power2.inOut', repeat: -1, repeatDelay: 0.8 }
          );
        });
      };

      window.addEventListener('ink:ready', play, { once: true });
      const fallback = window.setTimeout(play, 3800);
      return () => {
        window.removeEventListener('ink:ready', play);
        window.clearTimeout(fallback);
      };
    },
    { scope: ref }
  );

  return (
    <PaperSection id="silence" label="Act I — Silence" className="flex min-h-[135vh] items-center justify-center">
      <h2 className="sr-only">Prologue — silence</h2>
      <div ref={ref} className="flex flex-col items-center">
        <span
          data-kanji
          aria-hidden="true"
          className="select-none font-display text-[42vmin] leading-none text-washi opacity-0 will-change-transform"
          style={{ opacity: 0, color: 'rgba(245, 241, 232, 0.07)' }}
        >
          間
        </span>

        <div
          data-hint
          className="absolute bottom-14 flex flex-col items-center gap-4 opacity-0"
        >
          <span className="font-body text-[10px] uppercase tracking-calligraphy text-washi/55">
            begin
          </span>
          <span aria-hidden="true" className="block h-12 w-px overflow-hidden">
            <span data-hint-line className="block h-full w-full bg-washi/70" />
          </span>
        </div>
      </div>
    </PaperSection>
  );
}
