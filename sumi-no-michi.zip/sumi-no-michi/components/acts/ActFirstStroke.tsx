'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import PaperSection from '@/components/ink/PaperSection';
import CalligraphyTitle from '@/components/ink/CalligraphyTitle';
import InkReveal from '@/components/ink/InkReveal';
import SealStamp from '@/components/ui/SealStamp';
import { art } from '@/lib/assets';
import { identity } from '@/lib/content';
import { EASE, MQ } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger, useGSAP);

/**
 * ACT II — FIRST BRUSH STROKE
 *
 * Identity appears the way a painting starts. The name soaks in
 * first, fully legible against the void; THEN one confident
 * dry-brush stroke of luminous ink sweeps across beneath it —
 * the flourish never sits under the letters, so contrast is
 * never compromised. Below, the mountain painting glows in with
 * a slow parallax drift.
 */
export default function ActFirstStroke() {
  const ref = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mm = gsap.matchMedia();

      mm.add(MQ.motionOK, () => {
        // The stroke sweeps in beneath the name.
        gsap.fromTo(
          '[data-sweep]',
          { clipPath: 'inset(0% 100% 0% 0%)' },
          {
            clipPath: 'inset(0% 0% 0% 0%)',
            duration: 1.5,
            ease: EASE.sweep,
            scrollTrigger: { trigger: '[data-identity]', start: 'top 70%', once: true },
          }
        );

        // The mountain drifts slower than the camera.
        gsap.fromTo(
          '[data-parallax]',
          { yPercent: -7 },
          {
            yPercent: 7,
            ease: 'none',
            scrollTrigger: {
              trigger: '[data-hero]',
              start: 'top bottom',
              end: 'bottom top',
              scrub: true,
            },
          }
        );
      });
    },
    { scope: ref }
  );

  return (
    <PaperSection id="stroke" label="Act II — First Stroke">
      <div ref={ref}>
        {/* ————— identity ————— */}
        <div data-identity className="relative flex min-h-screen flex-col justify-center py-24">
          <p className="font-body text-[11px] uppercase tracking-calligraphy text-washi/55">
            portfolio · {identity.year}
          </p>

          <CalligraphyTitle
            as="h1"
            text={identity.name}
            className="mt-6 font-display text-6xl leading-[1.05] text-washi md:text-8xl"
          />

          {/* the first stroke — luminous ink, sweeping BELOW the name */}
          <div
            data-sweep
            aria-hidden="true"
            className="pointer-events-none -mt-2 -ml-[4%] h-16 w-[88%] max-w-3xl md:h-24"
            style={{ clipPath: 'inset(0% 100% 0% 0%)' }}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={art.stroke.src}
              alt=""
              width={art.stroke.width}
              height={art.stroke.height}
              loading="eager"
              decoding="async"
              className="plate h-full w-full object-cover object-center opacity-80"
            />
          </div>

          <div className="relative mt-10 flex items-start gap-6">
            <SealStamp char={identity.kanji} label={`Seal of ${identity.name}`} />
            <div>
              <p className="font-body text-sm uppercase tracking-wide2 text-washi/75">
                {identity.role}
              </p>
              <p className="mt-4 max-w-md font-body text-base leading-relaxed text-washi/75">
                {identity.line}
              </p>
            </div>
          </div>
        </div>

        {/* ————— the first painting ————— */}
        <figure data-hero className="mx-auto max-w-6xl pb-40">
          <InkReveal className="aspect-[21/9] w-full">
            <div data-parallax className="h-[116%] w-full">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={art.hero.src}
                alt={art.hero.alt}
                width={art.hero.width}
                height={art.hero.height}
                loading="eager"
                decoding="async"
                className="plate h-full w-full object-cover"
              />
            </div>
          </InkReveal>
          <figcaption className="mt-4 text-right font-body text-[11px] uppercase tracking-wide2 text-washi/55">
            somewhere between engineering and calligraphy
          </figcaption>
        </figure>
      </div>
    </PaperSection>
  );
}
