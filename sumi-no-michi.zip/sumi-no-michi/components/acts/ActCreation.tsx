'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import PaperSection from '@/components/ink/PaperSection';
import PaperCard from '@/components/ui/PaperCard';
import { works } from '@/lib/content';
import { MQ } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger, useGSAP);

/**
 * ACT IV — CREATION · the handscroll
 *
 * The signature move of the whole piece, and the most literal one:
 * an emakimono is read by unrolling it sideways, so here vertical
 * scroll is converted into a horizontal camera pan across the works.
 * The section pins, the track glides, each scroll drifts into focus
 * as the camera reaches it.
 *
 * Fallbacks are first-class, not afterthoughts:
 *  - reduced motion / no JS → the rail is a native, snap-aligned
 *    horizontal scroller (`.scroll-rail` in globals.css)
 *  - small screens → a plain vertical stack
 */
export default function ActCreation() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const railRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const rail = railRef.current;
      const track = trackRef.current;
      if (!rail || !track) return;

      const mm = gsap.matchMedia();

      mm.add(`${MQ.desktop} and ${MQ.motionOK}`, () => {
        rail.classList.add('is-pinned');

        const distance = () => track.scrollWidth - window.innerWidth;

        const pan = gsap.to(track, {
          x: () => -distance(),
          ease: 'none',
          scrollTrigger: {
            trigger: rail,
            start: 'top top',
            end: () => `+=${distance()}`,
            scrub: 1,
            pin: true,
            anticipatePin: 1,
            invalidateOnRefresh: true,
          },
        });

        // Each work drifts into focus as the camera reaches it.
        gsap.utils.toArray<HTMLElement>('[data-panel]', track).forEach((panel) => {
          gsap.fromTo(
            panel,
            { opacity: 0.25, y: 24 },
            {
              opacity: 1,
              y: 0,
              ease: 'power2.out',
              scrollTrigger: {
                trigger: panel,
                containerAnimation: pan,
                start: 'left 88%',
                end: 'left 55%',
                scrub: true,
              },
            }
          );
        });

        return () => {
          rail.classList.remove('is-pinned');
        };
      });
    },
    { scope: sectionRef }
  );

  return (
    <PaperSection id="creation" label="Act IV — Creation" className="!px-0">
      <div ref={sectionRef}>
        <div ref={railRef} className="scroll-rail snap-x snap-mandatory">
          <div className="flex md:h-screen md:items-center">
            <div
              ref={trackRef}
              className="flex w-full flex-col gap-20 px-6 py-28 will-change-transform md:w-auto md:flex-row md:items-center md:gap-[7vw] md:py-0 md:pl-24 md:pr-[16vw]"
            >
              <header className="shrink-0 md:w-[36vw]">
                <p className="font-body text-[11px] uppercase tracking-calligraphy text-washi/55">
                  作 · selected works
                </p>
                <h2 className="mt-4 font-display text-5xl leading-tight text-washi md:text-6xl">
                  The scroll
                  <br />
                  unrolls.
                </h2>
                <p className="mt-6 max-w-xs font-body text-base leading-relaxed text-washi/75">
                  Three works, read the way handscrolls have always been read — slowly, and
                  sideways.
                </p>
              </header>

              {works.map((w) => (
                <PaperCard key={w.title} {...w} />
              ))}

              <aside className="shrink-0 md:w-[30vw]">
                <p className="max-w-[22ch] font-display text-2xl leading-relaxed text-washi/75">
                  The quietest work is under NDA — ask, and I will tell you what I can.
                </p>
              </aside>
            </div>
          </div>
        </div>
      </div>
    </PaperSection>
  );
}
