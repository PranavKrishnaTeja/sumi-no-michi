'use client';

import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import PaperSection from '@/components/ink/PaperSection';
import CalligraphyTitle from '@/components/ink/CalligraphyTitle';
import { path } from '@/lib/content';
import { EASE, MQ } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger, useGSAP);

/**
 * ACT V — MASTERY · the timeline stroke
 *
 * A career as a single uninterrupted brushstroke. The wavering
 * vertical line draws itself in lockstep with the scroll (scrubbed
 * dashoffset), and each milestone soaks in as the ink reaches it.
 * The stroke wavers on purpose — a perfectly straight career is
 * a lie.
 */
export default function ActMastery() {
  const ref = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const line = ref.current?.querySelector<SVGPathElement>('[data-line]');
      if (!line) return;

      const mm = gsap.matchMedia();

      mm.add(MQ.motionOK, () => {
        const len = line.getTotalLength();
        gsap.set(line, { strokeDasharray: len, strokeDashoffset: len });
        gsap.to(line, {
          strokeDashoffset: 0,
          ease: 'none',
          scrollTrigger: {
            trigger: ref.current,
            start: 'top 65%',
            end: 'bottom 75%',
            scrub: 0.6,
          },
        });

        gsap.utils.toArray<HTMLElement>('[data-milestone]').forEach((el) => {
          gsap.fromTo(
            el,
            { opacity: 0, y: 24, filter: 'blur(4px)' },
            {
              opacity: 1,
              y: 0,
              filter: 'blur(0px)',
              duration: 1.1,
              ease: EASE.soak,
              scrollTrigger: { trigger: el, start: 'top 78%', once: true },
            }
          );
        });
      });
    },
    { scope: ref }
  );

  return (
    <PaperSection id="mastery" label="Act V — Mastery" className="py-44">
      <div ref={ref} className="relative mx-auto max-w-4xl">
        <p className="font-body text-[11px] uppercase tracking-calligraphy text-washi/55">
          歩 · the path
        </p>
        <CalligraphyTitle
          text="One continuous stroke"
          className="mt-4 font-display text-5xl text-washi md:text-6xl"
        />

        <div className="relative mt-24">
          {/* the stroke of the years */}
          <svg
            aria-hidden="true"
            focusable="false"
            preserveAspectRatio="none"
            viewBox="0 0 40 1000"
            className="absolute left-4 top-0 h-full w-8 md:left-1/2 md:-translate-x-1/2"
          >
            <path
              data-line
              d="M20 0 C 27 140, 12 300, 22 470 C 30 640, 13 810, 20 1000"
              fill="none"
              stroke="#F5F1E8"
              strokeWidth="3"
              strokeLinecap="round"
              vectorEffect="non-scaling-stroke"
              opacity="0.85"
            />
          </svg>

          <ol className="relative flex flex-col gap-28">
            {path.map((step, i) => (
              <li
                key={step.year}
                data-milestone
                className={`relative pl-16 md:w-1/2 md:pl-0 ${
                  i % 2 === 0
                    ? 'md:self-start md:pr-16 md:text-right'
                    : 'md:self-end md:pl-16'
                }`}
              >
                <span className="font-body text-[11px] uppercase tracking-wide2 text-washi/55">
                  {step.year}
                </span>
                <h3 className="mt-3 font-display text-3xl text-washi">{step.title}</h3>
                <p
                  className={`mt-4 max-w-xs font-body text-base leading-relaxed text-washi/75 ${
                    i % 2 === 0 ? 'md:ml-auto' : ''
                  }`}
                >
                  {step.body}
                </p>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </PaperSection>
  );
}
