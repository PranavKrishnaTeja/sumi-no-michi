import { useId } from 'react';

interface EnsoProps {
  size?: number;
  strokeWidth?: number;
  className?: string;
}

/**
 * The ensō — a circle drawn in one breath, deliberately left open.
 * The gap matters: a closed circle is finished; an open one is alive.
 *
 * feTurbulence + feDisplacementMap roughen the vector edge so the
 * stroke reads as bristle, not geometry. The path carries the class
 * `enso-path` so parent timelines can draw it with dashoffset.
 */
export default function Enso({ size = 160, strokeWidth = 9, className = '' }: EnsoProps) {
  const id = useId();
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 200 200"
      fill="none"
      className={className}
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        <filter id={id} x="-25%" y="-25%" width="150%" height="150%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="1" seed="7" result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale="3.4" />
        </filter>
      </defs>
      <path
        className="enso-path"
        filter={`url(#${id})`}
        d="M129 31 C 80 10, 25 50, 29 106 C 33 159, 88 186, 135 167 C 177 150, 191 99, 167 60"
        stroke="currentColor"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
      />
    </svg>
  );
}
