'use client';

import { useRef, type ReactNode } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { art } from '@/lib/assets';
import { EASE, MQ } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger, useGSAP);

interface InkRevealProps {
  children: ReactNode;
  className?: string;
}

/**
 * Imagery is never "loaded" — it is painted.
 *
 * Three synchronized layers, all compositor-only:
 *  1. a clip edge travels left → right (the paint line)
 *  2. the artwork settles from 1.06 scale / soft blur (ink drying)
 *  3. the generated brush stroke sweeps just ahead of the clip
 *     edge and exhausts its ink as it exits
 *
 * Under reduced motion the artwork is simply present.
 */
export default function InkReveal({ children, className = '' }: InkRevealProps) {
  const ref = useRef<HTMLDivElement>(null);

  useGSAP(
    () => {
      const mask = ref.current?.querySelector<HTMLElement>('[data-mask]');
      const inner = ref.current?.querySelector<HTMLElement>('[data-inner]');
      const brush = ref.current?.querySelector<HTMLElement>('[data-brush]');
      if (!mask || !inner || !brush) return;

      const mm = gsap.matchMedia();

      mm.add(MQ.motionOK, () => {
        const tl = gsap.timeline({
          scrollTrigger: { trigger: ref.current, start: 'top 78%', once: true },
        });
        tl.fromTo(
          mask,
          { clipPath: 'inset(0% 100% 0% 0%)' },
          { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.6, ease: EASE.sweep }
        )
          .fromTo(
            inner,
            { scale: 1.06, filter: 'blur(5px)' },
            { scale: 1, filter: 'blur(0px)', duration: 2.1, ease: EASE.soak },
            0
          )
          .fromTo(
            brush,
            { left: '-35%', opacity: 0.85 },
            { left: '108%', opacity: 0, duration: 1.6, ease: EASE.sweep },
            0
          );
      });

      mm.add('(prefers-reduced-motion: reduce)', () => {
        gsap.set(mask, { clipPath: 'inset(0% 0% 0% 0%)' });
        gsap.set(brush, { opacity: 0 });
      });
    },
    { scope: ref }
  );

  return (
    <div ref={ref} className={`relative overflow-hidden ${className}`}>
      <div data-mask className="h-full w-full" style={{ clipPath: 'inset(0% 100% 0% 0%)' }}>
        <div data-inner className="h-full w-full will-change-transform">
          {children}
        </div>
      </div>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        data-brush
        src={art.stroke.src}
        alt=""
        aria-hidden="true"
        loading="lazy"
        decoding="async"
        className="pointer-events-none absolute top-1/2 h-[170%] w-auto max-w-none -translate-y-1/2 opacity-0 plate"
      />
    </div>
  );
}
