import type { ReactNode } from 'react';

interface PaperSectionProps {
  id: string;
  label: string;
  className?: string;
  children: ReactNode;
}

/**
 * One act of the scroll. Provides the section landmark, the anchor
 * the ProgressStroke navigates to, and the default horizontal ma.
 */
export default function PaperSection({ id, label, className = '', children }: PaperSectionProps) {
  return (
    <section
      id={`act-${id}`}
      aria-label={label}
      className={`relative px-6 md:px-16 lg:px-24 ${className}`}
    >
      {children}
    </section>
  );
}
