'use client';

import { createElement, useRef, type ElementType } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { EASE, MQ } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger, useGSAP);

interface CalligraphyTitleProps {
  text: string;
  as?: ElementType;
  className?: string;
  delay?: number;
}

/**
 * NOT a template fade-up. Characters arrive the way ink arrives:
 * slightly wet (blurred), settling downward by a hair, sharpening
 * as they dry. Stagger runs in writing order. No bounce — ink
 * never bounces.
 *
 * Accessibility: the real string lives in aria-label; the animated
 * spans are hidden from the tree.
 */
export default function CalligraphyTitle({
  text,
  as = 'h2',
  className = '',
  delay = 0,
}: CalligraphyTitleProps) {
  const ref = useRef<HTMLElement>(null);

  useGSAP(
    () => {
      const chars = ref.current?.querySelectorAll('[data-ch]');
      if (!chars || chars.length === 0) return;

      const mm = gsap.matchMedia();

      mm.add(MQ.motionOK, () => {
        gsap.fromTo(
          chars,
          { opacity: 0, y: 14, filter: 'blur(7px)' },
          {
            opacity: 1,
            y: 0,
            filter: 'blur(0px)',
            duration: 1.05,
            ease: EASE.soak,
            delay,
            stagger: { each: 0.045, from: 'start' },
            scrollTrigger: { trigger: ref.current, start: 'top 82%', once: true },
          }
        );
      });
    },
    { scope: ref }
  );

  return createElement(
    as,
    { ref, className, 'aria-label': text },
    Array.from(text).map((c, i) =>
      createElement(
        'span',
        {
          key: i,
          'data-ch': true,
          'aria-hidden': 'true',
          className: 'inline-block will-change-transform',
        },
        c === ' ' ? '\u00A0' : c
      )
    )
  );
}
