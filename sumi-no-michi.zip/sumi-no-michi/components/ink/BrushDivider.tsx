'use client';

import { useId, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { EASE, MQ } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger, useGSAP);

/**
 * A horizontal stroke that draws itself when it enters the frame —
 * SVG dashoffset, roughened by displacement so the vector reads as
 * bristle. Used wherever a paragraph needs a breath after it.
 */
export default function BrushDivider({ className = '' }: { className?: string }) {
  const id = useId();
  const ref = useRef<SVGSVGElement>(null);

  useGSAP(
    () => {
      const path = ref.current?.querySelector('path');
      if (!path) return;
      const len = path.getTotalLength();

      const mm = gsap.matchMedia();
      mm.add(MQ.motionOK, () => {
        gsap.set(path, { strokeDasharray: len, strokeDashoffset: len });
        gsap.to(path, {
          strokeDashoffset: 0,
          duration: 1.3,
          ease: EASE.draw,
          scrollTrigger: { trigger: ref.current, start: 'top 88%', once: true },
        });
      });
    },
    { scope: ref }
  );

  return (
    <svg
      ref={ref}
      viewBox="0 0 600 24"
      preserveAspectRatio="none"
      aria-hidden="true"
      focusable="false"
      className={`h-5 w-full max-w-md text-washi ${className}`}
    >
      <defs>
        <filter id={id} x="-10%" y="-120%" width="120%" height="340%">
          <feTurbulence type="fractalNoise" baseFrequency="0.06 0.9" numOctaves="2" seed="11" result="n" />
          <feDisplacementMap in="SourceGraphic" in2="n" scale="4.5" />
        </filter>
      </defs>
      <path
        d="M8 14 C 110 8, 210 18, 330 12 C 430 7, 520 9, 592 13"
        fill="none"
        stroke="currentColor"
        strokeWidth="4.5"
        strokeLinecap="round"
        filter={`url(#${id})`}
      />
    </svg>
  );
}
