'use client';

import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { acts } from '@/lib/content';
import { getLenis } from '@/lib/lenis';

gsap.registerPlugin(ScrollTrigger);

/**
 * Persistent wayfinding — the one lesson taken most literally from
 * igloo.inc: a single-take narrative needs a quiet compass so the
 * visitor never feels lost inside it.
 *
 * A vertical stroke fills as ink rises through the scroll; the
 * current act shows as a kanji numeral; the six dots are real
 * buttons that hand the camera to Lenis.
 */
export default function ProgressStroke() {
  const fillRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const progress = ScrollTrigger.create({
      start: 0,
      end: () => ScrollTrigger.maxScroll(window),
      onUpdate: (self) => {
        if (fillRef.current) {
          fillRef.current.style.transform = `scaleY(${self.progress})`;
        }
      },
    });

    const watchers = acts.map((a, i) =>
      ScrollTrigger.create({
        trigger: `#act-${a.id}`,
        start: 'top center',
        end: 'bottom center',
        onToggle: (self) => {
          if (self.isActive) setActive(i);
        },
      })
    );

    return () => {
      progress.kill();
      watchers.forEach((w) => w.kill());
    };
  }, []);

  const go = (id: string) => {
    const target = `#act-${id}`;
    const lenis = getLenis();
    if (lenis) {
      lenis.scrollTo(target, { duration: 1.7 });
    } else {
      document.querySelector(target)?.scrollIntoView();
    }
  };

  return (
    <nav
      aria-label="Chapters"
      className="fixed right-6 top-1/2 z-40 hidden -translate-y-1/2 flex-col items-center gap-5 md:flex"
    >
      <span
        aria-hidden="true"
        className="font-display text-xl leading-none text-washi/75 transition-opacity duration-500"
      >
        {acts[active].kanji}
      </span>

      <div className="relative h-[34vh] w-px bg-washi/15" aria-hidden="true">
        <div
          ref={fillRef}
          className="absolute inset-0 origin-top bg-washi"
          style={{ transform: 'scaleY(0)' }}
        />
      </div>

      <ul className="flex flex-col items-center gap-3">
        {acts.map((a, i) => (
          <li key={a.id}>
            <button
              type="button"
              onClick={() => go(a.id)}
              aria-label={`Act ${i + 1} — ${a.label}`}
              aria-current={active === i ? 'true' : undefined}
              className={`block h-2 w-2 rounded-full transition-all duration-500 ease-ink ${
                active === i
                  ? 'scale-125 bg-washi'
                  : 'bg-washi/25 hover:bg-washi/60'
              }`}
            />
          </li>
        ))}
      </ul>

      <span className="tategaki font-body text-[10px] uppercase tracking-wide2 text-washi/55">
        {acts[active].label}
      </span>
    </nav>
  );
}
