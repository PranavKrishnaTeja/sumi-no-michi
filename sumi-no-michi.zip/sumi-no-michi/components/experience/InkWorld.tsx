'use client';

import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { prefersReducedMotion } from '@/lib/motion';

/**
 * INK WORLD — the WebGL heart of the night scroll.
 *
 * The whole page floats inside a 3D corridor of suspended ink:
 * ~3,000 luminous motes hang in fog, and the scrollbar drives the
 * camera straight through them — scroll = dolly, exactly the
 * igloo.inc grammar, spoken in ink instead of ice.
 *
 * The set-piece: at 60% depth the motes condense into a giant
 * open ensō, and the camera passes THROUGH the gap in the circle
 * during Act IV (Creation). The pointer steers the camera a few
 * degrees, like leaning to look.
 *
 * Discipline:
 *  - one geometry, one draw call, additive blending, exp2 fog
 *  - DPR capped at 1.5, particle count halved on small screens
 *  - paused when the tab hides; never mounted under reduced motion
 *  - sprite texture is generated on a canvas (no network, no CORS)
 */
export default function InkWorld() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const host = ref.current;
    if (!host || prefersReducedMotion()) return;

    const renderer = new THREE.WebGLRenderer({
      antialias: false,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.setSize(window.innerWidth, window.innerHeight);
    host.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0d0b08, 0.052);

    const camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      0.1,
      120
    );
    camera.position.set(0, 0, 10);

    // soft ink-dab sprite, drawn locally (no CORS, no network)
    const spriteCanvas = document.createElement('canvas');
    spriteCanvas.width = spriteCanvas.height = 64;
    const sctx = spriteCanvas.getContext('2d');
    if (sctx) {
      const grad = sctx.createRadialGradient(32, 32, 0, 32, 32, 32);
      grad.addColorStop(0, 'rgba(245,241,232,1)');
      grad.addColorStop(0.35, 'rgba(245,241,232,0.5)');
      grad.addColorStop(1, 'rgba(245,241,232,0)');
      sctx.fillStyle = grad;
      sctx.fillRect(0, 0, 64, 64);
    }
    const sprite = new THREE.CanvasTexture(spriteCanvas);

    const small = window.innerWidth < 900;
    const DRIFT = small ? 1200 : 2400; // suspended motes along the corridor
    const RING = small ? 350 : 700; // the great ensō
    const COUNT = DRIFT + RING;
    const positions = new Float32Array(COUNT * 3);

    // the corridor: motes scattered from just behind the camera to deep fog
    for (let i = 0; i < DRIFT; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 26;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 16;
      positions[i * 3 + 2] = 12 - Math.random() * 74;
    }

    // the ensō gate at z = -24: an open ring the camera flies through.
    // The gap sits upper-right — the same 7% opening as every ensō here.
    const GAP = 0.5; // radians left undrawn
    for (let i = 0; i < RING; i++) {
      const t = i / RING;
      const angle = GAP * 0.5 + Math.PI * 0.25 + (Math.PI * 2 - GAP) * t;
      // stroke breathes: thick mid-stroke, tapering toward the ends
      const thickness = 0.28 + Math.sin(t * Math.PI) * 0.5;
      const radius = 5.8 + (Math.random() - 0.5) * thickness;
      const j = DRIFT + i;
      positions[j * 3] = Math.cos(angle) * radius + (Math.random() - 0.5) * 0.12;
      positions[j * 3 + 1] = Math.sin(angle) * radius + (Math.random() - 0.5) * 0.12;
      positions[j * 3 + 2] = -24 + (Math.random() - 0.5) * 1.1;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      size: 0.14,
      map: sprite,
      color: 0xf5f1e8,
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      sizeAttenuation: true,
    });
    const points = new THREE.Points(geometry, material);
    scene.add(points);

    // pointer steers the camera a few degrees — leaning, not dragging
    let mx = 0;
    let my = 0;
    const onPointer = (e: PointerEvent) => {
      mx = e.clientX / window.innerWidth - 0.5;
      my = e.clientY / window.innerHeight - 0.5;
    };
    window.addEventListener('pointermove', onPointer, { passive: true });

    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', onResize);

    let raf = 0;
    let running = true;
    const clock = new THREE.Clock();

    const tick = () => {
      if (!running) return;
      const t = clock.getElapsedTime();

      // scroll progress → depth. Lenis drives native scroll, so
      // window.scrollY is always the eased value — free sync.
      const max = document.documentElement.scrollHeight - window.innerHeight;
      const p = max > 0 ? window.scrollY / max : 0;

      camera.position.z = 10 - p * 52; // crosses the ensō plane at ~65%
      camera.position.x += (mx * 1.2 - camera.position.x) * 0.045;
      camera.position.y += (-my * 0.9 - camera.position.y) * 0.045;
      camera.rotation.y += (-mx * 0.14 - camera.rotation.y) * 0.05;
      camera.rotation.x += (-my * 0.09 - camera.rotation.x) * 0.05;

      points.rotation.z = t * 0.014; // the whole world turns, slowly

      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    const onVisibility = () => {
      running = !document.hidden;
      if (running) {
        clock.start();
        raf = requestAnimationFrame(tick);
      } else {
        cancelAnimationFrame(raf);
      }
    };
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener('pointermove', onPointer);
      window.removeEventListener('resize', onResize);
      document.removeEventListener('visibilitychange', onVisibility);
      geometry.dispose();
      material.dispose();
      sprite.dispose();
      renderer.dispose();
      if (renderer.domElement.parentElement === host) {
        host.removeChild(renderer.domElement);
      }
    };
  }, []);

  return <div ref={ref} aria-hidden="true" className="pointer-events-none fixed inset-0 z-0" />;
}
