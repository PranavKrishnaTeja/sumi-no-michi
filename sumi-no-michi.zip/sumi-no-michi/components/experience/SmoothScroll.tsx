'use client';

import { useEffect, type ReactNode } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import { setLenis } from '@/lib/lenis';
import { prefersReducedMotion } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger);

/**
 * Scrolling is camera movement.
 *
 * lerp 0.08 + wheelMultiplier 0.92 makes the page feel heavy and
 * organic — a dolly with mass, never floaty. Lenis drives native
 * window scroll, ScrollTrigger listens, GSAP's ticker keeps them
 * in the same frame so pins never shudder.
 */
export default function SmoothScroll({ children }: { children: ReactNode }) {
  useEffect(() => {
    if (prefersReducedMotion()) return; // native scroll for reduced motion

    const lenis = new Lenis({
      lerp: 0.08,
      wheelMultiplier: 0.92,
      touchMultiplier: 1.15,
    });
    setLenis(lenis);

    lenis.on('scroll', ScrollTrigger.update);

    const raf = (time: number) => {
      lenis.raf(time * 1000);
    };
    gsap.ticker.add(raf);
    gsap.ticker.lagSmoothing(0);

    return () => {
      gsap.ticker.remove(raf);
      lenis.destroy();
      setLenis(null);
    };
  }, []);

  return <>{children}</>;
}
