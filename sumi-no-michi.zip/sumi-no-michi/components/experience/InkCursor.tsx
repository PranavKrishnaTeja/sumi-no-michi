'use client';

import { useEffect, useRef } from 'react';
import { prefersReducedMotion } from '@/lib/motion';

interface Dab {
  x: number;
  y: number;
  r: number;
  a: number;
}

/**
 * The visitor holds the brush. Moving the pointer leaves soft dabs
 * of ink that spread slightly as they fade — wet ink sinking into
 * paper. Mounted only for fine pointers; never on touch, never
 * under reduced motion. Multiply blend seats it into the washi.
 */
export default function InkCursor() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    if (!window.matchMedia('(pointer: fine)').matches) return;
    if (prefersReducedMotion()) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    let dabs: Dab[] = [];
    let raf = 0;
    let running = true;

    const resize = () => {
      canvas.width = Math.floor(window.innerWidth * dpr);
      canvas.height = Math.floor(window.innerHeight * dpr);
    };
    resize();

    const onMove = (e: PointerEvent) => {
      dabs.push({
        x: e.clientX * dpr,
        y: e.clientY * dpr,
        r: (2.2 + Math.random() * 2.4) * dpr,
        a: 0.15,
      });
      if (dabs.length > 70) dabs.shift();
    };

    const tick = () => {
      if (!running) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      dabs = dabs.filter((d) => d.a > 0.004);
      for (const d of dabs) {
        ctx.beginPath();
        ctx.fillStyle = `rgba(245, 241, 232, ${d.a})`;
        ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
        ctx.fill();
        d.a *= 0.9; // ink dries
        d.r += 0.22 * dpr; // ink spreads
      }
      raf = requestAnimationFrame(tick);
    };

    const onVisibility = () => {
      running = !document.hidden;
      if (running) raf = requestAnimationFrame(tick);
      else cancelAnimationFrame(raf);
    };

    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('resize', resize);
    document.addEventListener('visibilitychange', onVisibility);
    raf = requestAnimationFrame(tick);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('resize', resize);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, []);

  return (
    <canvas
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-[70] h-full w-full mix-blend-screen"
    />
  );
}
