'use client';

import { useRef, useState } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import Enso from '@/components/ink/Enso';
import { EASE, prefersReducedMotion } from '@/lib/motion';

gsap.registerPlugin(useGSAP);

/**
 * Act 0 — the overture.
 *
 * First visit: an ensō draws itself in one breath (~1.3s), the title
 * soaks in, then the whole sheet lifts upward like paper peeled from
 * a stack. Return visits get a 0.45s bow. Reduced motion skips it.
 *
 * When the sheet is gone we dispatch `ink:ready` so Act I can begin.
 */
export default function InkLoader() {
  const ref = useRef<HTMLDivElement>(null);
  const [done, setDone] = useState(false);

  useGSAP(
    () => {
      const el = ref.current;
      if (!el) return;

      const finish = () => {
        setDone(true);
        window.dispatchEvent(new CustomEvent('ink:ready'));
      };

      const revisit = sessionStorage.getItem('sumi:visited') === '1';
      sessionStorage.setItem('sumi:visited', '1');

      if (prefersReducedMotion()) {
        finish();
        return;
      }

      const tl = gsap.timeline({ onComplete: finish });

      if (revisit) {
        tl.to(el, { opacity: 0, duration: 0.45, ease: EASE.soak, delay: 0.1 });
        return;
      }

      const path = el.querySelector<SVGPathElement>('.enso-path');
      if (path) {
        const len = path.getTotalLength();
        gsap.set(path, { strokeDasharray: len, strokeDashoffset: len });
        tl.to(path, {
          strokeDashoffset: len * 0.07, // never close the circle
          duration: 1.3,
          ease: EASE.draw,
        });
      }

      tl.fromTo(
        '[data-loader-word]',
        { opacity: 0, filter: 'blur(7px)', y: 8 },
        { opacity: 1, filter: 'blur(0px)', y: 0, duration: 0.7, ease: EASE.soak },
        '-=0.55'
      ).to(el, {
        clipPath: 'inset(0 0 100% 0)',
        duration: 0.95,
        ease: EASE.sweep,
        delay: 0.4,
      });
    },
    { scope: ref }
  );

  if (done) return null;

  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="fixed inset-0 z-[80] flex flex-col items-center justify-center gap-8 bg-sumi-950 text-washi"
      style={{ clipPath: 'inset(0 0 0 0)' }}
    >
      <Enso size={132} strokeWidth={10} />
      <p
        data-loader-word
        className="font-display text-sm tracking-calligraphy uppercase text-washi/75"
      >
        墨の道 <span className="mx-2 text-washi/40">—</span> the way of ink
      </p>
    </div>
  );
}
