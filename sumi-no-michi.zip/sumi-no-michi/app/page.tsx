import SmoothScroll from '@/components/experience/SmoothScroll';
import InkLoader from '@/components/experience/InkLoader';
import InkWorld from '@/components/experience/InkWorld';
import InkCursor from '@/components/experience/InkCursor';
import ProgressStroke from '@/components/experience/ProgressStroke';
import ActSilence from '@/components/acts/ActSilence';
import ActFirstStroke from '@/components/acts/ActFirstStroke';
import ActDiscovery from '@/components/acts/ActDiscovery';
import ActCreation from '@/components/acts/ActCreation';
import ActMastery from '@/components/acts/ActMastery';
import ActLegacy from '@/components/acts/ActLegacy';

/**
 * 墨の道 — THE WAY OF INK
 *
 * One page, six acts, no cuts. Scrolling is the camera; the page
 * is the handscroll it moves across.
 */
export default function Home() {
  return (
    <SmoothScroll>
      <InkLoader />
      <InkWorld />
      <InkCursor />
      <ProgressStroke />

      <main id="main" className="relative z-10">
        <ActSilence />
        <ActFirstStroke />
        <ActDiscovery />
        <ActCreation />
        <ActMastery />
        <ActLegacy />
      </main>
    </SmoothScroll>
  );
}
