import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import './globals.css';
import { identity } from '@/lib/content';

export const metadata: Metadata = {
  title: `${identity.name} — 墨の道 · The Way of Ink`,
  description:
    'A portfolio told as a night handscroll: six acts, one continuous stroke, and a camera that flies through a world of luminous ink.',
  openGraph: {
    title: `${identity.name} — The Way of Ink`,
    description: 'A cinematic portfolio painted in luminous ink. Scroll to fly.',
    type: 'website',
  },
};

export const viewport: Viewport = {
  themeColor: '#0D0B08',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        {/*
          Fonts are linked (not next/font) so the project builds in
          offline/CI environments. Swap to next/font/google locally
          for self-hosted subsetting — see README → Performance.
        */}
        <link
          href="https://fonts.googleapis.com/css2?family=Shippori+Mincho:wght@500;600;800&family=Inter:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-body">
        <a href="#main" className="skip-link">
          Skip to content
        </a>

        {/* one film-grain layer unifies every act */}
        <div aria-hidden="true" className="grain" />

        {children}
      </body>
    </html>
  );
}
